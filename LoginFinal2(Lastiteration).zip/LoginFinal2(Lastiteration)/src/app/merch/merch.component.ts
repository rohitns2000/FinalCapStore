import { Component, OnInit } from '@angular/core';

export class Merchant{
  constructor(
    public merchantId:number=0,
    public firstName:string="",
    public lastName:string="",
    public company:string="",
    public emailid:string="",
    public mobileno:number=0,
    public password:string="",
    public photo:string="",
    public rating:number=0,
    public status:string=""
  ){}
}
@Component({
  selector: 'app-merch',
  templateUrl: './merch.component.html',
  styleUrls: ['./merch.component.css']
})
export class MerchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
