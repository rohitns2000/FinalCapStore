package com.cg.bootdemo2.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bootdemo2.dao.AdminDAO;
import com.cg.bootdemo2.dao.CouponDAO;
import com.cg.bootdemo2.dao.CustomerDAO;
import com.cg.bootdemo2.dao.MerchantDAO;
import com.cg.bootdemo2.entities.Admin;
import com.cg.bootdemo2.entities.Coupon;
import com.cg.bootdemo2.entities.User1;
import com.cg.bootdemo2.entities.Merchant;


@Service
@Transactional
public class WalletServiceImpl implements WalletService{
	@Autowired AdminDAO dao;
	@Autowired CustomerDAO dao1;
	@Autowired MerchantDAO dao2;
	@Autowired CouponDAO dao3;

	@Override
	public Admin findAdmin(String username,String password) {
		Admin wa1 = null;
		List<Admin> lst = dao.findAll();
		System.out.println(lst);
		for(Admin wa : lst)
		{
			if((wa.getEmailid().equals(username))&&(wa.getPassword().equals(password))) {
				wa1 = wa;
			}
		}
//		if(wa1 == null)
//		{
//			throw new ApplicationException("No account found in-Admin");
//		}
		return wa1;
	}

	@Override
	public User1 findCustomer(String username, String password) {
		User1 wa1 = null;
		List<User1> lst = dao1.findAll();
		for(User1 wa : lst)
		{
			if((wa.getEmailid().equals(username))&&(wa.getPassword().equals(password))) {
				wa1 = wa;
			}
		}
//		if(wa1 == null)
//		{
//			throw new ApplicationException("No account found in-Customer");
//		}
		return wa1;
	}

	@Override
	public Merchant findMerchant(String username, String password) {
		Merchant wa1 = null;
		List<Merchant> lst = dao2.findAll();
		for(Merchant wa : lst)
		{
			if((wa.getEmailid().equals(username))&&(wa.getPassword().equals(password))) {
				wa1 = wa;
			}
		}
//		if(wa1 == null)
//		{
//			throw new ApplicationException("No account found in-Customer");
//		}
		return wa1;
	}


	@Override
	public boolean addAdmin(Admin ad) {
		dao.save(ad);
		return true;
	}

	@Override
	public boolean addCustomer(User1 cu) {
		dao1.save(cu);
		return true;
	}

	@Override
	public boolean addMerchant(Merchant me) {
		dao2.save(me);
		return true;
	}
	
	@Override
	public boolean addCoupon(Coupon co) {
		dao3.save(co);
		return true;
	}

	@Override
	public boolean removeCoupon(Coupon co) {
		dao3.delete(co);
		return true;
	}

	@Override
	public List<Coupon> showAllCoupon() {
		List<Coupon> lst = dao3.findAll();
		return lst;
	}

}
