package com.cg.bootdemo2.services;

import java.util.List;

import com.cg.bootdemo2.entities.Admin;
import com.cg.bootdemo2.entities.Coupon;
import com.cg.bootdemo2.entities.User1;
import com.cg.bootdemo2.entities.Merchant;


public interface WalletService {
	

public boolean addAdmin(Admin ad);
public boolean addCustomer(User1 cu);
public boolean addMerchant(Merchant me);

public Admin findAdmin(String username,String password);
public User1 findCustomer(String username,String password);
public Merchant findMerchant(String username,String password);

public boolean addCoupon(Coupon co);
public boolean removeCoupon(Coupon co);
public List<Coupon> showAllCoupon();

}
