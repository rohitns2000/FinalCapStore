package com.cg.bootdemo2;


public class Bootdemo2ApplicationTests {

	public void contextLoads() {
	}

}
